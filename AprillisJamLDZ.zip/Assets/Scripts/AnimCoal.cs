﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimCoal : MonoBehaviour {

    private Vector3 orgPos;

    public float amp = 1;
    public float offset = 0;
    public float speed = 1;



	// Use this for initialization
	void Start () {
        orgPos = transform.position;
	}
	
	// Update is called once per frame
	void Update () {
        transform.position = orgPos + Vector3.up * Mathf.Sin(speed * (Time.timeSinceLevelLoad + offset)) * amp;
	}
}
