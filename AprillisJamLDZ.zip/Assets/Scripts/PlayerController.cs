﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    public GameObject playSec;
    public Animator anis = null;
    public GameObject plana = null;
    public float speed = 1;
    private Rigidbody2D RiBO;
    public float jumpForce = 400;
    public float power = 100;
    public GameObject Activ = null;
    public GameObject firstPlay = null;
    public GameObject fixeed = null;
    public GameObject secondScene = null;
    public GameObject te = null;
    public int life = 3;
    public GameObject h1;
    public GameObject h2;
    public GameObject h3;

    public GameObject anim = null;

    private void Start()
    {
        RiBO = GetComponent<Rigidbody2D>();
        anis = GetComponent<Animator>();
        playSec.SetActive(false);
    }

    private void FixedUpdate() //movement, so far
    {
        Debug.Log(life);
        float moveHorizontal = Input.GetAxis("Horizontal");
        // float moveVertical = Input.GetAxis("Vertical");

        Vector2 movement = new Vector2(moveHorizontal, 0);
        Vector2 jumpvelo = new Vector2(0f, RiBO.velocity.y);

        if (Input.GetButtonDown("Jump"))
        {
            jumpvelo += Vector2.up * power;
        }

        RiBO.velocity = (movement * speed) + jumpvelo;
    
        transform.localRotation = moveHorizontal < 0 ? Quaternion.Euler(0, 180, 0) : Quaternion.Euler(0, 0, 0);
        anis.SetBool("isMoving", movement.magnitude > 0 ? true : false);

        if (playSec != null)
        {
            if (playSec.transform.position.y <= -3)
            {
                if (life > 1)
                {
                    playSec.transform.position = new Vector3(39, 0, -1);
                    life = life - 1;
                    Debug.Log(life);
                    if(life == 2)
                    {
                        h1.SetActive(false);
                    }
                    if (life == 1)
                    {
                        h3.SetActive(false);
                    }
                    
                }
                else if (life <= 1) 
                {
                    SceneManager.LoadScene("LostScene");
                    Debug.Log(life);
                }
            }
        }

        if(Input.anyKeyDown == true)
        {
            fixeed.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D trig)
    {
        if (trig.gameObject.name == "Activation")
        {
            playSec.SetActive(true);
            plana.SetActive(true);
            firstPlay.SetActive(false);
            //speed = 0;
            //speed = 300;
            te.SetActive(true);
        }

        if (trig.gameObject.name == "TrapCard")
        {
            anim.transform.position = new Vector3(0, 0, 0);
        }

        if (trig.gameObject.name == "GaO6")
        {
            plana.SetActive(false);
            playSec.SetActive(false);
            firstPlay.SetActive(true);
            firstPlay.transform.position = new Vector3(-4, 0, -1);
            Activ.SetActive(false);
            anim.SetActive(false);
            fixeed.SetActive(true);
            te.SetActive(false);
        }

        if (trig.gameObject.name == "WinTag")
        {
            SceneManager.LoadScene("WInScene");
        }
    }
}
