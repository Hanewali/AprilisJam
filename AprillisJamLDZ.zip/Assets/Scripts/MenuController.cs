﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MenuController : MonoBehaviour {

    public Canvas menu;
    public Button play;
    public Button authors;
    
	// Use this for initialization
	void Start () {
        menu = menu.GetComponent<Canvas>();
        //play = play.GetComponent<Button>();
        authors = authors.GetComponent<Button>();
        play.onClick.AddListener(TaskOnClick);
        authors.onClick.AddListener(TaskOnClick2);
    }

    void TaskOnClick()
    {
        Debug.Log("psenis");
        SceneManager.LoadScene("FirstScene");
    }

    void TaskOnClick2()
    {
        Debug.Log("penis");
        SceneManager.LoadScene("AuthorsScene");
    }

}
