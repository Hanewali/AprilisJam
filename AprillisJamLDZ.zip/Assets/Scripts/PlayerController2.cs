﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController2 : MonoBehaviour
{
    public Animator anis = null;
    public GameObject plana = null;
    public float speed = 1;
    private Rigidbody2D RiBO;
    public GameObject map;

    public GameObject anim = null;

    private void Start()
    {
        RiBO = GetComponent<Rigidbody2D>();
        anis = GetComponent<Animator>();
    }

    private void FixedUpdate() //movement, so far
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector2 movement = new Vector2(moveHorizontal, moveVertical);
        //Vector2 jumpvelo = new Vector2(0f, RiBO.velocity.y);

        //if (Input.GetButtonDown("Jump"))
        //{
        //    jumpvelo += Vector2.up * power;

        //}

        RiBO.velocity = (movement * speed);

        transform.localRotation = moveHorizontal < 0 ? Quaternion.Euler(0, 180, 0) : Quaternion.Euler(0, 0, 0);
        anis.SetBool("isMoving", movement.magnitude > 0 ? true : false);
    }

}
